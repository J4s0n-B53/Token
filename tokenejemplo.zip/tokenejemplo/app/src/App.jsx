import './App.css'
import {Route, Router, Routes} from 'react-router'
import Home from './pages/Home'
import Login from './pages/Login'
import About from './pages/About'
import ProtectedRoute from './context/ProtectedRoute'
import { useAuth } from './context/AuthContext'
import Perfil from './pages/Perfil'

function App() {

  const {isAuthenticated} = useAuth()

  return (
    <>
      <Routes>
        <Route 
          element={<ProtectedRoute isAllowed={isAuthenticated === true} redirectTo="/login" />}
        >
          <Route path='/' element={<Home />} />
          <Route path='/about' element={<About />} />
          <Route path='/perfil' element={<Perfil />} />
        </Route>
        <Route 
          path='/login' 
          element={
            <ProtectedRoute isAllowed={isAuthenticated === false} redirectTo="/">
              <Login />
            </ProtectedRoute>
          } 
          />
      </Routes>
    </>
  )
}

export default App
