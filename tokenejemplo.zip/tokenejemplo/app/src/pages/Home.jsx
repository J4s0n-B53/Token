import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router';

const Home = () => {

    const {logout} = useAuth()

    const handleCerrarSesion = () => {
        logout()
    }

    return (
        <div className='center'>
            <nav className="subnav">
                <Link to="perfil">Perfil</Link>
                <Link to="about">About</Link>
            </nav>

            <button className="logout-btn" onClick={handleCerrarSesion}>
                Cerrar sesión
            </button>
        </div>
    );
}

export default Home;
