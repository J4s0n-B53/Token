import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router';

const fakeToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNjA2MyIsIm5hbWUiOiJNYXJ2aW4gTGluYXJlcyIsImFkbWluIjp0cnVlLCJlbWFpbCI6Im1hcnZpbmhsY0BnbWFpbC5jb20iLCJpYXQiOjE1MTYyMzkwMjJ9.yKcs7RrUnA45OnEE1IN7-85aLje629-gcG9FVr5Fzmk"

const Login = () => {

    const {login,token} = useAuth()
    const navigate = useNavigate()

    const habndleOnSubmit = (e) => {
        e.preventDefault()
        login(fakeToken)
        navigate('/')
        console.log('login')
    }

    return (
        <div className='center'>
            <section className="card">
                <h2>Iniciar sesión</h2>

                <form onSubmit={habndleOnSubmit} className="form">
                    <div className="form-group">
                    <label>Usuario</label>
                    <input
                        type="text"
                        onChange={(e) => console.log(e.target.value)}
                        placeholder="Escribe tu usuario"
                    />
                    </div>

                    <div className="form-group">
                    <label>Contraseña</label>
                    <input
                        type="password"
                        onChange={(e) => console.log(e.target.value)}
                        placeholder="Escribe tu contraseña"
                    />
                    </div>

                    <button type="submit">Ingresar</button>
                </form>
            </section>
        </div>
    );
}

export default Login;
