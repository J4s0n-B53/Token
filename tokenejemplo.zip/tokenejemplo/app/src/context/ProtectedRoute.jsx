import { Navigate, Outlet } from "react-router";

function ProtectedRoute({ children, redirectTo, isAllowed }) {

  if (isAllowed === false) {
    return <Navigate to={redirectTo} />;
  }

  return children ? children : <Outlet />
}

export default ProtectedRoute;