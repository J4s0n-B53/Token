import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [token, setToken] = useState(() => localStorage.getItem('token'))

  console.log('token->',token)

  const login = (jwtoken) => {
        setToken(() => {
          localStorage.setItem('token',jwtoken);
          return jwtoken
        })
        setIsAuthenticated(() => jwtoken !== null || jwtoken !== undefined)
  };
  
  const logout = () => {
        setToken(() => {
          localStorage.removeItem('token')
          return null
        })
        setIsAuthenticated(false)
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}