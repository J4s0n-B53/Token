require('dotenv').config()

const express = require('express');
const app = express();
const cors = require('cors')
const PORT = 3000;

app.use(express.json());

app.use(cors({
    origin: "*",
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credenticals: false,
}))

const apiRoutes = require('./src/routes/index');
app.use('/todo/v1', apiRoutes);


//Lanzar el servidor
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});