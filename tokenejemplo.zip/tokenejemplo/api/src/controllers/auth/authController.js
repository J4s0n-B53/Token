const pool = require('../../config/db')
const jwt = require('jsonwebtoken')

function autenticarUsuario(user,psw){
    

    if(user === 'marvinhlc' && psw === 'torta-jamon-123'){
        const payload = {
            user: user,
            rol:'admin',
            id: 1
        }
        const privateKey = 'roky-balboa-versus-chuck-norris'
        const options = {expiresIn:'7d'}

        const token = jwt.sign(
            payload,
            privateKey,
            options
        )

        return token;
    }

    return null;
}

module.exports = {
    autenticarUsuario
}