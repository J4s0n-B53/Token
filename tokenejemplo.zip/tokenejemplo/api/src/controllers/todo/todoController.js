const pool = require('../../config/db')

const PRIORIDADES_VALIDAS = ['NORMAL', 'MEDIA', 'ALTA']
const ESTADOS_VALIDOS = ['PENDIENTE', 'FINALIZADO', 'CERRADO']

function validarPrioridad(prioridad) {
    if (prioridad == null) return true
    return PRIORIDADES_VALIDAS.includes(prioridad)
}

function validarEstado(estado) {
    if (estado == null) return true
    return ESTADOS_VALIDOS.includes(estado)
}

function validarDescripcion(descripcion) {
    return typeof descripcion === 'string' && descripcion.trim().length > 0
}

async function getTodoById(actividadId) {
    const sql = `
    SELECT
      actividad_id,
      descripcion,
      prioridad,
      estado,
      creacion,
      actualizacion
    FROM actividades
    WHERE actividad_id = ?
    LIMIT 1
  `

    const [rows] = await pool.execute(sql, [actividadId])
    return rows[0] || null
}

const getAllTodos = async () => {
    const [rows] = await pool.query(
        `SELECT 
            a.actividad_id,
            a.descripcion,
            a.prioridad,
            a.estado
        FROM actividades a
        ORDER BY a.actividad_id DESC
        LIMIT 100;`
    );
    return rows;
}

async function createTodo(data) {
    const {
        descripcion,
        prioridad = 'NORMAL',
        estado = 'PENDIENTE'
    } = data

    if (!validarDescripcion(descripcion)) {
        throw new Error('La descripcion es obligatoria')
    }

    if (!validarPrioridad(prioridad)) {
        throw new Error('La prioridad no es válida')
    }

    if (!validarEstado(estado)) {
        throw new Error('El estado no es válido')
    }

    const sql = `
    INSERT INTO actividades (
      descripcion,
      prioridad,
      estado
    ) VALUES (?, ?, ?)
  `

    const [result] = await pool.execute(sql, [
        descripcion.trim(),
        prioridad,
        estado
    ])

    return await getTodoById(result.insertId)
}

module.exports = {
    getTodoById,
    getAllTodos,
    createTodo,
}