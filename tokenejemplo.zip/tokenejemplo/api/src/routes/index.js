const express = require('express')
const router = express.Router();

router.get('/', (req, res) => {
    res.send('api is working')
})

const rootTodo = require('./todo/index.js')
const rootAuth = require('./auth/index.js')

router.use('/todos', rootTodo);
router.use('/auth', rootAuth)

module.exports = router;