const express = require('express');
const { autenticarUsuario } = require('../../controllers/auth/authController');
const router = express.Router();

router.post('/login', async (req, res) => {
    const {
        user,
        psw
    } = req.body

    console.log('user->',user)
    console.log('psw->',psw)

    const respuesta = await autenticarUsuario(user,psw);

    console.log('respuesta->',respuesta)

    res.json({
        ok: respuesta !== null,
        data: respuesta
    });
})

module.exports = router;