const express = require('express')
const router = express.Router()

const loginUser = require('./loginUser')

router.use(loginUser);

module.exports = router;