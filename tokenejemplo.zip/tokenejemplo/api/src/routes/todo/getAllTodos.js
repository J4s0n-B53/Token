const express = require('express');
const { getAllTodos } = require('../../controllers/todo/todoController');
const router = express.Router();

router.get('/', async (req, res) => {
    const todos = await getAllTodos()
    res.json(todos);
})

module.exports = router;