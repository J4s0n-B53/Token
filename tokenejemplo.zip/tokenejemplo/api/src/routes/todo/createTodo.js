const express = require('express');
const { createTodo } = require('../../controllers/todo/todoController');
const verifyToken = require('../../middlewares/authMiddleware');
const router = express.Router();

router.post('/', verifyToken, async (req, res) => {
    const {
        descripcion,
        prioridad,
        estado
    } = req.body

    console.log(req.body)

    const respuesta = await createTodo({ descripcion, prioridad, estado })
    res.json(respuesta);
})

module.exports = router;