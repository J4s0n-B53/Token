const express = require('express')
const router = express.Router()

const getAllTodos = require('./getAllTodos')
const createTodos = require('./createTodo')
// const updateTodos = require('')
// const deleteTodos = require('')
// const getTodoById = require('')

router.use(getAllTodos);
router.use(createTodos);
//router.use(updateTodos);
//router.use(deleteTodos);
//router.use(getTodoById);

module.exports = router;