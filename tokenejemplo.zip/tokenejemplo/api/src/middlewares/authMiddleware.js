const jwt = require('jsonwebtoken')
const privateKey = 'roky-balboa-versus-chuck-norris'

const verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ ok: false, message: 'No autorizado' })
    }

    const token = authHeader.split(' ')[1]
    
    console.log('token-splited->', token)

    try {
        const decoded = jwt.verify(token, privateKey)
        req.token = decoded
        next()
    } catch (error) {
        console.log('error->',error)
        return res.status(401).json({ ok: false, message: 'Token inválido' })
    }
}

module.exports = verifyToken